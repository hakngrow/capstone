# GA Capstone Project Package

This is a simple package of my GA Capstone project on Timseries 
machine learning. It has yet to be finalized, so please stay tune 
for more updates.

You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.