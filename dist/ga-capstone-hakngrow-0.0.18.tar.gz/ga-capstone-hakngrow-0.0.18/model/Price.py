class Price:

    def __init__(self, id, ticker, interval, datetime, open, high, low, close, volume):

        self.id = id
        self.ticker = ticker
        self.interval = interval
        self.datetime = datetime
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.volume = volume